# Banking-System
This project is based on Java 8

#Software Requirements
JDK8
JRE8
Eclipse neon 2.0

#Important steps before execution
Before starting the application, you need to replace external jars
(goto project's properties and then in build path under libraries add external jars)  
with your's javamail.jar(files are already given in project) otherwise it will create some error.
And under EmailValid.java dont forget to put your valid email and password

Just fork it using the link https://github.com/abhishek021/Banking-System and use it.
